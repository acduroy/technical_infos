#!/usr/bin/env python
__author__ = 'rbabaylan'


import re
import os
import sys
import getopt
import platform
import subprocess
import PyFioUtil


def pyfio_display_usage():
    print ''
    print '*' * PyFioUtil.Constant.SEPARATOR
    print '  PyFio Main Console Application 1.0.0 BETA'
    print '  Copyright 2014 LAR-Bab Software LLC'
    print '  www.liobaashlyritchie.blogspot.com'
    print '  No warranty expressed or implied.'
    print '*' * PyFioUtil.Constant.SEPARATOR
    print ''
    print 'Usage: PyFioMain [OPTIONS]'
    print ''
    print '  Required Options:'
    print '  -d Device    Set device address (e.g. /dev/sda, /dev/sda1, /dev/sda2, etc.)'
    print '  -s SerNmb    Set serial number of device (e.g. ENCFP000000)'
    print ''
    print '  Optional:'
    print '  -w Worker    Set number of workers (default is from Workload.csv)'
    print '  -q QueueD    Set threads or queue depth (default is from Workload.csv)'
    print '  -b pattern   Set data pattern (zero or random, default is random)'
    print '  -a alignment Set block alignment (default is 4kb)'
    print '  -f workload  Set workload file in CSV format (default is Workload.csv)'
    print '  -u unaligned Set block unalignment (default is OFF)'
    print '  -v VerifFlg  Set data verification flag (default is OFF)'
    print '  -c Cmprsion  Set data compression (default is 0 - no data compression)'
    print '  -p PreCnFlg  Set pre-conditioned flag (default is OFF)'
    print '  -i Interval  Set log interval in seconds (default is 0 - log at end)'
    print "  -t Tempture  Set temperature (default is +25C)"
    print ''
    print 'Examples:'
    print ''
    print '  PyFioMain -d /dev/sda -s ENCFP000001'
    print '    Run FIO program given the physical target drive and serial number while the'
    print '    rest of the configuration remains to default.'
    print ''
    print '  PyFioMain -d /dev/sda1 -s ENCFP000001'
    print '    Run FIO program given the formatted target drive and serial number while the'
    print '    rest of the configuration remains to default.'
    print ''
    print '  PyFioMain -d 1 -s ENCFP000001'
    print '    Run FIO program given the physical target drive 1 and serial number while the'
    print '    rest of the configuration remains to default.'
    print ''
    print '  PyFioMain -d f: -s ENCFP000001'
    print '    Run FIO program given the formatted target drive F: and serial number while the'
    print '    rest of the configuration remains to default.'
    print ''
    print '  PyFioMain -d /dev/sda -s ENCFP000001 -w 16 -q 16'
    print '    Run FIO program to test a ddrive /dev/sda with 16 workers and 16 threads'
    print '    with serial number ENCFP000001.'
    print '*' * PyFioUtil.Constant.SEPARATOR
    print ''
    return


def pyfio_parse_argument(argv):
    # copy argv to temporary variable
    temp_argv = argv

    # instantiate the constant in this program
    const = PyFioUtil.Constant()

    # convert the arguments into a list and evaluate and get the
    # arguments needed for the program
    try:
        opts, args = getopt.getopt(temp_argv, "d:s:w:q:v:c:p:t:a:b:u:f:i:")
    except getopt.GetoptError as err:
        # exception is raise if option are not valid
        pyfio_display_usage()
        print 'Error: ',
        print(err)
        sys.exit()

    # initialized parameters of the program
    worker = str(const.ZERO)
    queue = str(const.ZERO)
    block_alignment = const.DEF_BLOCK_ALIGNMENT
    data_pattern = const.DEF_DATA_PATTERN
    workload = const.DEF_WORKLOAD_FILENAME
    block_unalign = const.OFF
    verify = const.OFF
    compress = const.ZERO
    precon = const.OFF
    interval = const.ZERO
    temperature = const.DEF_TEMPERATURE

    # we parse the selection command line option
    for opt, arg in opts:
        if arg and not arg.isspace():
            if opt == const.D_OPTION:
                # get the device address
                device = arg
                if device.isdigit() is True:
                    if platform.system() == const.WINDOWS_OS:
                        device = const.WIN_PHYSICAL_DEV + str(arg)
                        try:
                            fd = os.open(device, os.O_RDONLY | os.O_BINARY)
                        except OSError:
                            pyfio_display_usage()
                            print 'Error: option -d, invalid %s device argument' % device
                            sys.exit()
                        else:
                            os.close(fd)
                    else:
                        pyfio_display_usage()
                        print 'Error: option -d, invalid %s device argument' % device
                        sys.exit()
                else:
                    if platform.system() == const.WINDOWS_OS:
                        drive_letter = str(const.WIN_LOGICAL_DEV)[const.FOUR:]
                        device = str(const.WIN_LOGICAL_DEV).replace(drive_letter, str(arg).upper())
                        try:
                            fd = os.open(device, os.O_RDONLY | os.O_BINARY)
                        except OSError:
                            pyfio_display_usage()
                            print 'Error: option -d, invalid %s device argument' % device
                            sys.exit()
                        else:
                            os.close(fd)
                            device = device.replace(const.COLON, const.ESCAPE_SEQUENCE)
                    else:
                        if os.path.exists(device) is False:   # does the working dir exists?
                            pyfio_display_usage()
                            print 'Error: option -d, invalid %s device argument' % device
                            sys.exit()
            elif opt == const.S_OPTION:
                # get the serial number
                serial = str(arg).upper()
            elif opt == const.W_OPTION:
                # get the new worker/threads
                worker = arg
                # check if integer input or not
                if worker.isdigit() is False:
                    pyfio_display_usage()
                    print 'Error: option -w, invalid worker=%s argument' % worker
                    sys.exit()
                else:   # we check if valid from 1 to 999
                    if int(worker) > (const.ONE_THOUSAND - const.ONE):
                        pyfio_display_usage()
                        print 'Error: option -w, invalid worker=%s argument (1 to 999 only)' % worker
                        sys.exit()
            elif opt == const.Q_OPTION:
                # get the new iodepth
                queue = arg
                # check if integer input or not
                if queue.isdigit() is False:
                    pyfio_display_usage()
                    print 'Error: option -q, invalid queue=%s depth argument' % queue
                    sys.exit()
                else:   # we check if valid number from 1 to 999
                    if int(queue) > (const.ONE_THOUSAND - const.ONE):
                        pyfio_display_usage()
                        print 'Error: option -q invalid queue=%s depth argument (1 to 999 only)' % queue
                        sys.exit()
            elif opt == const.A_OPTION:
                # get the block alignment
                block_alignment = arg
                flag, _ = PyFioUtil.util_validate_block_alignment(block_alignment)
                if flag is False:
                    pyfio_display_usage()
                    print 'Error: option -a, invalid block_alignment=%s argument' % block_alignment
                    sys.exit()
            elif opt == const.B_OPTION:
                # get the data pattern of either zero or random
                data_pattern = str(arg)
                if data_pattern != const.DEF_DATA_PATTERN and data_pattern != const.DATA_PATTERN_ZERO:
                    pyfio_display_usage()
                    print 'Error: option -b, invalid pattern=%s flag argument' % data_pattern
                    sys.exit()
            elif opt == const.U_OPTION:
                # get if it requires block unaligned
                block_unalign = str(arg).upper()
                if (block_unalign in (const.OFF, const.ON)) is False:
                    pyfio_display_usage()
                    print 'Error: option -u, invalid block_unalign=%s flag argument' % block_unalign
                    sys.exit()
            elif opt == const.F_OPTION:
                curr_dir = os.getcwd()
                workload_dir = curr_dir + os.sep + const.WORKLOAD_FOLDER_NAME
                workload = arg
                workload_filename = workload_dir + os.sep + workload
                if os.path.isfile(workload_filename) is False:
                    pyfio_display_usage()
                    print 'Error: option -f, workload=%s file does not exist' % workload
                    sys.exit()
            elif opt == const.V_OPTION:
                # get the verification flag
                verify = str(arg).upper()
                if (verify in (const.OFF, const.ON)) is False:
                    pyfio_display_usage()
                    print 'Error: option -v, invalid verify=%s flag argument' % verify
                    sys.exit()
            elif opt == const.C_OPTION:
                # get the compression value
                compress = arg
                if compress.isdigit() is False:
                    pyfio_display_usage()
                    print 'Error: option -c, invalid compress=%s argument' % compress
                    sys.exit()
                else:   # we check if valid from 0 to 100
                    if int(compress) > const.ONE_HUNDRED:
                        pyfio_display_usage()
                        print 'Error: option -c, invalid compress=%s argument (0 to 100 only)' % compress
                        sys.exit()
            elif opt == const.P_OPTION:
                # get the preconditioned flag
                precon = str(arg).upper()
                if (precon in (const.OFF, const.ON)) is False:
                    pyfio_display_usage()
                    print 'Error: option -p, invalid precon=%s flag argument' % precon
                    sys.exit()
            elif opt == const.I_OPTION:
                # get the logging interval in seconds
                interval = arg
                if interval.isdigit() is False:
                    pyfio_display_usage()
                    print 'Error: option -i, invalid interval=%s argument' % interval
                    sys.exit()
                else:   # check if valid from 1 second to 60 seconds
                    if int(interval) > const.SIXTY:
                        pyfio_display_usage()
                        print 'Error: option -i invalid interval=%s argument (1 to 60 only)' % interval
                        sys.exit()
            else:
                # get the temperature
                temperature = str(arg).upper()
                if (const.SINGLE_QUOTE in temperature) is True or \
                   (const.DOUBLE_QUOTE in temperature) is True:
                    pyfio_display_usage()
                    print 'Error: option -t, invalid temperature=%s argument' % temperature
                    sys.exit()
                # we need to check the temperature input if valid thru regular expression
                temperature_list = re.findall(const.REGEX_EXPRESSION, temperature)
                if temperature_list.__len__() > const.TWO or \
                   temperature_list.__len__() < const.TWO:
                    pyfio_display_usage()
                    print 'Error: option -t, invalid temperature=%s argument' % temperature
                    sys.exit()
                else:
                    if temperature_list[const.ONE] != const.CHAR_C:
                        pyfio_display_usage()
                        print 'Error: option -t, invalid temperature=%s argument' % temperature
                        sys.exit()
        else:
            pyfio_display_usage()
            print 'Error: option -', opt, ' not recognized'
            sys.exit()

    # fio option/profile
    profile = {
        const.D_OPTION: device,
        const.S_OPTION: serial,
        const.W_OPTION: worker,
        const.Q_OPTION: queue,
        const.A_OPTION: block_alignment,
        const.B_OPTION: data_pattern,
        const.U_OPTION: block_unalign,
        const.F_OPTION: workload,
        const.V_OPTION: verify,
        const.C_OPTION: compress,
        const.P_OPTION: precon,
        const.I_OPTION: interval,
        const.T_OPTION: temperature,
    }

    # return all the profile need for this program
    return profile


def pyfio_display_profile(profile):
    print ''
    print '*' * PyFioUtil.Constant.SEPARATOR
    print '        FIO Test Configuration'
    print '*' * PyFioUtil.Constant.SEPARATOR
    print '  Device          : %s' % profile[PyFioUtil.Constant.D_OPTION]
    print '  Serial Number   : %s' % profile[PyFioUtil.Constant.S_OPTION]

    if int(profile[PyFioUtil.Constant.W_OPTION]) == PyFioUtil.Constant.ZERO:
        print "  Worker          : refer to 'workload file' for worker setting"
    else:
        print '  Worker          : %s' % profile[PyFioUtil.Constant.W_OPTION]

    if int(profile[PyFioUtil.Constant.Q_OPTION]) == PyFioUtil.Constant.ZERO:
        print "  Queue Depth     : refer to 'workload file' for queue depth setting"
    else:
        print '  Queue Depth     : %s' % profile[PyFioUtil.Constant.Q_OPTION]

    if profile[PyFioUtil.Constant.U_OPTION] == PyFioUtil.Constant.ON:
        print '  Block Alignment : ---'
    else:
        print '  Block Alignment : %s' % profile[PyFioUtil.Constant.A_OPTION]

    print '  Data Pattern    : %s' % profile[PyFioUtil.Constant.B_OPTION]
    print '  Block Unaligned : %s' % profile[PyFioUtil.Constant.U_OPTION]
    print '  Workload File   : %s' % profile[PyFioUtil.Constant.F_OPTION]
    print '  Verify Data     : %s' % profile[PyFioUtil.Constant.V_OPTION]

    if int(profile[PyFioUtil.Constant.C_OPTION]) == PyFioUtil.Constant.ZERO:
        print '  Compress Data   : %s (no data compression)' % profile[PyFioUtil.Constant.C_OPTION]
    else:
        print '  Compress Data   : %s (data compression)' % profile[PyFioUtil.Constant.C_OPTION]

    print '  Precondition    : %s' % profile[PyFioUtil.Constant.P_OPTION]

    if int(profile[PyFioUtil.Constant.I_OPTION]) == PyFioUtil.Constant.ZERO:
        print '  Log Interval    : 0 (log at end of test)'
    else:
        print '  Log Interval    : %s' % profile[PyFioUtil.Constant.I_OPTION]

    print '  Temperature     : %s' % profile[PyFioUtil.Constant.T_OPTION]
    print '*' * PyFioUtil.Constant.SEPARATOR
    print ''

    # ask the user if to proceed with the test or not
    response = raw_input("Do you want to proceed the test? [Y/n]: ")
    flag = response.lower() in list(PyFioUtil.Constant.RESPONSE_LIST)
    if flag is False:
        sys.exit()
    return


def main():
    # instantiate the constant in this program
    const = PyFioUtil.Constant()

    # if no argument inputted, display program usage
    if len(sys.argv) < const.FOUR:
        # display the program usage
        pyfio_display_usage()
        print 'Error: insufficient command line argument'
        return

    # check if -d and -s option are in the program argument
    d_flag = const.D_OPTION in sys.argv
    s_flag = const.S_OPTION in sys.argv
    if d_flag is False or s_flag is False:
        # display the program usage
        pyfio_display_usage()
        print 'Error: insufficient command line argument'
        return

    # we check if align & unaligned are set. Only one are set not both
    a_flag = const.A_OPTION in sys.argv
    u_flag = const.U_OPTION in sys.argv
    if a_flag is True and u_flag is True:
        # display the program usage
        pyfio_display_usage()
        print 'Error: both block_alignment and block_unaligned are set'
        print 'Error: choose either block_align or block_unalign'
        return

    # if with argument inputted, parse it
    argv = sys.argv[const.ONE:]
    profile = pyfio_parse_argument(argv)

    # display the profile with inputs from user
    pyfio_display_profile(profile)

    # we now check if preconditioning is set
    if profile[const.P_OPTION] == const.ON:
        # we create the precon fio config file
        precon_list = PyFioUtil.util_create_precon_fio_cfg(profile[const.D_OPTION])

    # we now create all jobs for fio based from the given workload in csv
    fio_dict = PyFioUtil.util_create_job_fio_cfg(profile)

    # prepare fio related parameters
    if platform.system() == const.LINUX_OS:
        fio_param0 = const.FIO_PROGRAM_NAME                                     # fio program name
    elif platform.system() == const.WINDOWS_OS:
        curr_dir = os.getcwd()
        fio_dir = curr_dir + const.FIO_FOLDER
        fio_param0 = fio_dir + os.sep + const.FIO_PROGRAM_NAME
    else:
        pyfio_display_usage()
        print 'Error: Unknown OS is not currently supported'
        return

    fio_param1 = const.FIO_MINIMAL                                              # use minimal for terse output
    fio_param2 = const.FIO_OUTPUT_FORMAT + const.EQUALS + const.OUTPUT_TERSE    # terse output format

    # we need to provide the logging interval in seconds if provided by user
    fio_param3 = ''
    if int(profile[const.I_OPTION]) != const.ZERO:
        fio_param3 = const.FIO_INTERVAL + const.EQUALS + profile[const.I_OPTION]

    # run fio program for preconditioning requirement if enabled
    if profile[const.P_OPTION] == const.ON:
        fio_param4 = const.FIO_OUTPUT + const.EQUALS + precon_list[const.ONE]       # fio precon log file
        fio_param5 = precon_list[const.ZERO]                                        # fio precon config file

        # spawn the fio program with required parameter
        fio_param = fio_param0 + const.SPACE + fio_param1 + const.SPACE + \
                    fio_param2 + const.SPACE + fio_param3 + const.SPACE + \
                    fio_param4 + const.SPACE + fio_param5

        print '\n\nFIO Execution: Precondition - Write Sequential Fill {%s}' % const.PRECON_BLOCKSIZE
        subprocess.call(fio_param, shell=True)      # execute the fio program

    # run fio program for all job listed in the workload file
    for entry_num, entry_list in fio_dict.items():
        fio_param4 = const.FIO_OUTPUT + const.EQUALS + entry_list[const.TWO]        # fio job log file
        fio_param5 = entry_list[const.ONE]                                          # fio job config file

        # spawn the fio program with required parameter
        fio_param = fio_param0 + const.SPACE + fio_param1 + const.SPACE + \
                    fio_param2 + const.SPACE + fio_param3 + const.SPACE + \
                    fio_param4 + const.SPACE + fio_param5

        print '\n\nFIO Execution: Job No.%s - %s {%s}' % (str(entry_num), entry_list[const.ZERO], entry_list[const.THREE])
        subprocess.call(fio_param, shell=True)      # execute the fio program

    # if the status interval is non-zero, we will not summarize the individual job log
    if int(profile[const.I_OPTION]) == const.ZERO:
        # generate the summary job log file from individual job log file
        # excluding the precon job log file
        PyFioUtil.util_create_summary_fio_log(fio_dict, profile[const.S_OPTION], \
                                              profile[const.T_OPTION], profile[const.F_OPTION])

    # all done
    print '\n\nall done.'
    return


if __name__ == '__main__':
    # the entry point of the program
    main()

#!/usr/bin/env python
__author__ = 'rbabaylan'


import os
import time
import csv
import platform


class Constant:
    WINDOWS_OS = 'Windows'
    LINUX_OS = 'Linux'
    OS_PLATFORM_32 = '32bit'
    OS_PLATFORM_64 = '64bit'

    # FIO related arguments
    OUTPUT_TERSE = 'terse'
    OUTPUT_NORMAL = 'normal'
    OUTPUT_JSON = 'json'

    FIO_MINIMAL = '--minimal'
    FIO_OUTPUT_FORMAT = '--output-format'
    FIO_OUTPUT = '--output'
    FIO_INTERVAL = '--status-interval'

    # -----------------------------------------------
    # user can modify this settings enclosed in a box
    # -----------------------------------------------
    PRECON_RUNTIME = 14400
    PRECON_LOOP_COUNT = 2
    PRECON_IODEPTH = 1
    PRECON_NUMJOBS = 1
    PRECON_BLOCKSIZE = '128kb'

    if platform.system() == LINUX_OS:
        FIO_PROGRAM_NAME = '/usr/bin/fio'
    elif platform.system() == WINDOWS_OS:
        FIO_PROGRAM_NAME = 'fio.exe'
        if platform.architecture()[0] == OS_PLATFORM_32:
            FIO_FOLDER = '\\Exec\\fio-2.1.10-x86'
        elif platform.architecture()[0] == OS_PLATFORM_64:
            FIO_FOLDER = '\\Exec\\fio-2.1.10-x64'
        else:
            FIO_FOLDER = ''
            print 'Error: Unknown OS Platform, not currently supported'
    else:
        FIO_PROGRAM_NAME = ''
        print 'Error: Unknown OS, not currently supported'
    # -----------------------------------------------

    ZERO = 0
    ONE = 1
    TWO = 2
    THREE = 3
    FOUR = 4
    FIVE = 5
    SIX = 6
    SEVEN = 7
    EIGHT = 8

    SIXTY = 60
    ONE_HUNDRED = 100
    ONE_THOUSAND = 1000
    SEPARATOR = 70

    HALF_KB = 512
    ONE_KB = 1024
    ONE_MB = ONE_KB * ONE_KB
    ONE_GB = ONE_MB * ONE_KB

    ONE_HUNDRED_PERCENT = '100%'
    DOUBLE_BACKSLASH = r'\\'
    ESCAPE_SEQUENCE = r'\:'
    PERCENT = '%'
    UNDERSCORE = '_'
    EQUALS = '='
    SPACE = ' '
    COLON = ':'
    COMMA = ','
    SINGLE_QUOTE = "'"
    DOUBLE_QUOTE = '"'
    CHAR_C = 'C'

    D_OPTION = '-d'
    S_OPTION = '-s'
    W_OPTION = '-w'
    Q_OPTION = '-q'
    A_OPTION = '-a'
    F_OPTION = '-f'
    B_OPTION = '-b'
    U_OPTION = '-u'
    V_OPTION = '-v'
    C_OPTION = '-c'
    P_OPTION = '-p'
    I_OPTION = '-i'
    T_OPTION = '-t'

    OFF = 'OFF'
    ON = 'ON'

    BYTE = 'b'
    KILOBYTE = 'kb'
    MEGABYTE = 'mb'
    GIGABYTE = 'gb'

    XXX = 'xxx'
    U_XXX = '_xxx'

    DEF_TEMPERATURE = '+25C'
    DEF_BLOCK_ALIGNMENT = '4kb'
    DEF_DATA_PATTERN = 'random'
    DATA_PATTERN_ZERO = 'zero'

    CFG_FOLDER_NAME = 'Config'
    LOG_FOLDER_NAME = 'Logs'
    CFG_FILE_EXTENSION = '.fio'
    LOG_FILE_EXTENSION = '.log'

    PRECON_CFG_FILENAME = 'PreconCfg'
    PRECON_LOG_FILENAME = 'Precon'
    JOB_CFG_FILENAME = 'JobCfg'
    JOB_LOG_FILENAME = 'Job'
    ALL_JOB_LOG_FILENAME = 'All'

    CSV_FILE_HEADER = 'Test No.'
    WORKLOAD_FOLDER_NAME = 'Workload'
    DEF_WORKLOAD_FILENAME = 'Workload.csv'

    REGEX_EXPRESSION = r"[^\W\d_]+|\d+"
    RESPONSE_LIST = ('yes', 'y')

    WIN_PHYSICAL_DEV = r'\\.\PhysicalDrive'
    WIN_LOGICAL_DEV = r'\\.\L:'

    def __setattr__(self, *_):
        pass


def util_validate_block_alignment(ba):
    # initialize the block size dictionary
    bs_dict = {
        Constant.BYTE: Constant.HALF_KB,
        Constant.KILOBYTE: Constant.ONE_KB,
        Constant.MEGABYTE: Constant.ONE_MB,
        Constant.GIGABYTE: Constant.ONE_GB,
    }

    # get the last two character of string to determine if
    # it is a valid suffix for allowed block alignment
    temp = str(ba[-Constant.TWO:]).lower()
    flag = temp in (Constant.KILOBYTE, Constant.MEGABYTE, Constant.GIGABYTE)

    # we get the length of the string
    slen = len(ba)
    power_two = Constant.SPACE
    if flag is False:
        # we check if it is a byte
        temp = str(ba[-Constant.ONE:]).lower()
        if temp == Constant.BYTE:
            flag = True

            # we check if it is a digit
            power_two = temp
            temp = str(ba[:(slen - Constant.ONE)])
    else:
        # now we check if the given alignment is a
        # multiple of 512 (binary 2^n)
        power_two = temp
        temp = str(ba[:(slen - Constant.TWO)])

    # now we check if it is a digit
    bs = Constant.ZERO
    if temp.isdigit() is False:
        flag = False
    else:   # it is a digit, we need to check if multiple of 512
        bs = int(temp) * bs_dict[power_two]
        if (bs % Constant.HALF_KB) != Constant.ZERO:
            flag = False

    return flag, bs


def util_create_precon_fio_cfg(device):
    # we need to check if "Config" folder exist, if not create the folder
    curr_dir = os.getcwd()
    cfg_dir = curr_dir + os.sep + Constant.CFG_FOLDER_NAME
    if os.path.exists(cfg_dir) is False:    # does the 'Config' dir exists?
        os.mkdir(cfg_dir)   # create the folder

    # define the precon config file
    cfg_precon_filename = cfg_dir + os.sep + Constant.PRECON_CFG_FILENAME + Constant.CFG_FILE_EXTENSION

    # check if "Log" folder exist, if not create the folder
    log_dir = curr_dir + os.sep + Constant.LOG_FOLDER_NAME
    if os.path.exists(log_dir) is False:    # does the 'Log' dir exists?
        os.mkdir(log_dir)

    # define the precon log file
    log_precon_filename = log_dir + os.sep + Constant.PRECON_LOG_FILENAME + Constant.LOG_FILE_EXTENSION

    # define how many iterations required for
    # pre-conditioning and steady state
    iterations = Constant.PRECON_LOOP_COUNT     # default is 2 but user can change to preferred value

    with open(cfg_precon_filename, 'wb') as writer:
        # write the header of the Precon FIO config file
        writer.write('; FIO Precon Config File\n')
        writer.write('; Copyright 2014 LAR-Bab Software LLC\n')
        writer.write('; www.liobaashlyritchie.blogspot.com\n')
        writer.write('; ' + time.strftime("%m/%d/%Y") + ' ' + time.strftime("%I:%M:%S %p") + '\n;\n\n')

        # write the global section of the Precon FIO config file
        _, bsize = util_validate_block_alignment(Constant.PRECON_BLOCKSIZE)
        writer.write('[precon-sequential-fill,%s,100,0]\n' % str(bsize))
        writer.write('description=Precon Sequential Fill {%s}\n' % Constant.PRECON_BLOCKSIZE)

        if platform.system() == Constant.LINUX_OS:
            writer.write('ioengine=libaio\n')
        else:
            writer.write('ioengine=windowsaio\n')
            writer.write('thread\n')

        writer.write('direct=1\n')
        writer.write('iodepth=%s\n' % str(Constant.PRECON_IODEPTH))
        writer.write('numjobs=%s\n' % str(Constant.PRECON_NUMJOBS))
        writer.write('rw=write\n')
        writer.write('loops=%s\n' % str(iterations))
        writer.write('bs=%s\n' % Constant.PRECON_BLOCKSIZE)
        writer.write('group_reporting\n')
        writer.write('filename=%s\n' % device)

        # we need to add the size parameter of fio for Windows accessing
        # a file or a formatted partition
        # if platform.system() == Constant.WINDOWS_OS:
        #     if Constant.COLON in device:
        #         writer.write('thread\n')
        #         writer.write('runtime=%s\n' % str(Constant.PRECON_RUNTIME))
        #         writer.write('time_based\n')
        #         writer.write('size=%s\n\n' % Constant.ONE_HUNDRED_PERCENT)

    # return a list for precon related file required for fio program
    fio_list = (cfg_precon_filename, log_precon_filename)
    return fio_list


def util_create_job_fio_cfg(profile):
    # instantiate fio dictionary needed for executing fio program
    fio_dict = {}

    # check if 'Config' folder exists
    curr_dir = os.getcwd()
    cfg_dir = curr_dir + os.sep + Constant.CFG_FOLDER_NAME
    if os.path.exists(cfg_dir) is False:    # does the 'Config' dir exists?
        os.mkdir(cfg_dir)

    # check if 'Log' folder exists
    job_log_folder = curr_dir + os.sep + Constant.LOG_FOLDER_NAME
    if os.path.exists(job_log_folder) is False:
        os.mkdir(job_log_folder)

    # we get the workload file and open it for parsing
    workload = profile[Constant.F_OPTION]
    workload_folder = curr_dir + os.sep + Constant.WORKLOAD_FOLDER_NAME
    workload_filename = workload_folder + os.sep + workload

    # separate the filename and file extension into two separate variables
    filename, extension = os.path.splitext(workload)

    # we crawl the given workload line by line and then parse its data
    with open(workload_filename, 'rb') as csvreader:
        reader = csv.reader(csvreader, delimiter=',', quotechar='|')
        for row in reader:
            if Constant.CSV_FILE_HEADER in row:
                # skip the first line of the csv file
                continue
            else:   # process succeeding line
                # CSV format description:
                # col1 = Test No.    || col2 = File Size    || col3 = Block Size
                # col4 = Access Type || col5 = Run Time     || col6 = Rampup Time
                # col7 = Start Delay || col8 = Numjobs      || col9 = IOdepth

                # parse each row to get the job to be added in
                # the main FIO config file based from the format above
                testnum = row[Constant.ZERO]                    # Test No.
                filesize = str(row[Constant.ONE]).lower()       # File Size
                blocksize = str(row[Constant.TWO]).lower()      # Block Size
                access_type = row[Constant.THREE]               # Access Type
                access_list = access_type.split()               # Access Type converted to list
                runtime = row[Constant.FOUR]                    # Run Time
                ramptime = row[Constant.FIVE]                   # Ramp-Up Time
                startdelay = row[Constant.SIX]                  # Start Delay
                threads = row[Constant.SEVEN]                   # Number of Jobs or Thread
                iodepth = row[Constant.EIGHT]                   # Outstanding IO or IOdepth

                # get the time and date then append to job config file and log file
                now = time.strftime("%m%d%Y") + Constant.UNDERSCORE + \
                      time.strftime("%H%M")

                # set the initial job filename of the fio config file
                job_filename = Constant.JOB_CFG_FILENAME + Constant.UNDERSCORE + filename + \
                               Constant.UNDERSCORE + profile[Constant.S_OPTION] + \
                               Constant.UNDERSCORE + profile[Constant.T_OPTION] + \
                               Constant.UNDERSCORE + now

                # we now create the job file for the fio program
                job_filename = job_filename + Constant.UNDERSCORE + testnum + Constant.CFG_FILE_EXTENSION
                job_dir_n_file = cfg_dir + os.sep + job_filename

                # set the initial job log filename
                job_log_filename = Constant.JOB_LOG_FILENAME + Constant.UNDERSCORE + filename + \
                                   Constant.UNDERSCORE + profile[Constant.S_OPTION] + \
                                   Constant.UNDERSCORE + profile[Constant.T_OPTION] + \
                                   Constant.UNDERSCORE + now

                # we set the job log filename based on the test number
                job_log_filename = job_log_filename + Constant.UNDERSCORE + testnum + Constant.LOG_FILE_EXTENSION
                job_log_dir_n_file = job_log_folder + os.sep + job_log_filename

                # now we parse the access_type list for read or write access
                # get percentage sequential workload
                percent_sequential = int(access_list[Constant.ZERO].rstrip(Constant.PERCENT))
                # get the sequential IO access
                percent_mix = int(access_list[Constant.TWO].rstrip(Constant.PERCENT))

                with open(job_dir_n_file, 'wb') as writer:
                    # write the header of the Main FIO config file
                    writer.write('; FIO Main Job Config File\n')
                    writer.write('; Copyright 2014 LAR-Bab Software LLC\n')
                    writer.write('; www.liobaashlyritchie.blogspot.com\n')
                    writer.write('; ' + time.strftime("%m/%d/%Y") + ' ' + time.strftime("%I:%M:%S %p") + '\n;\n\n')

                    # write the global section of the FIO config file
                    # writer.write('[global]\n')
                    _, bsize = util_validate_block_alignment(blocksize)
                    writer.write('[job-no.%s,%s,%s,%s]\n' % (testnum, str(bsize), str(percent_sequential), str(percent_mix)))
                    writer.write('description=%s {%s}\n' % (access_type, blocksize))

                    if platform.system() == Constant.LINUX_OS:
                        writer.write('ioengine=libaio\n')
                    else:
                        writer.write('ioengine=windowsaio\n')
                        writer.write('thread\n')

                    writer.write('direct=1\n')
                    writer.write('bs=%s\n' % blocksize)

                    # check if file size were define from the workload
                    if filesize and not filesize.isspace():
                        writer.write('size=%s\n' % filesize)

                    # we check if the test requires align or unalign access
                    if profile[Constant.U_OPTION] == Constant.ON:
                        writer.write('bs_unaligned\n')
                    else:   # we can define block alignment
                        writer.write('ba=%s\n' % str(profile[Constant.A_OPTION]).lower())
                        writer.write('norandommap\n')

                    # check if we need to use iodepth from the workload or
                    # from user input provided thru -q option
                    if int(profile[Constant.Q_OPTION]) == Constant.ZERO:
                        writer.write('iodepth=%s\n' % iodepth)
                    else:   # user provided a queue depth
                        writer.write('iodepth=%s\n' % profile[Constant.Q_OPTION])

                    # check if we need the use numjobs from the workload or
                    # from user input provided thru -w option
                    if int(profile[Constant.W_OPTION]) == Constant.ZERO:
                        writer.write('numjobs=%s\n' % threads)
                    else:   # user provided a worker
                        writer.write('numjobs=%s\n' % profile[Constant.W_OPTION])

                    writer.write('runtime=%s\n' % runtime)
                    writer.write('ramp_time=%s\n' % ramptime)
                    writer.write('startdelay=%s\n' % startdelay)
                    writer.write('time_based\n')
                    writer.write('group_reporting\n')
                    writer.write('filename=%s\n' % profile[Constant.D_OPTION])

                    # we need to add the size parameter of fio for Windows accessing
                    # a file or a formatted partition
                    # if platform.system() == Constant.WINDOWS_OS:
                    #     if Constant.COLON in profile[Constant.D_OPTION]:
                    #         writer.write('size=%s\n' % Constant.ONE_HUNDRED_PERCENT)
                    #         writer.write('thread\n')

                    # we now check if data pattern is zero or random
                    if profile[Constant.B_OPTION] == Constant.DATA_PATTERN_ZERO:
                        writer.write('zero_buffers\n')

                    # we now check if verify data is required or not
                    if profile[Constant.V_OPTION] == Constant.ON:
                        writer.write('do_verify=1\n')
                        writer.write('verify=sha256\n')
                        writer.write('verify_dump=1\n')

                    # we now check if it requires to compress data
                    if profile[Constant.C_OPTION] != Constant.ZERO:
                        writer.write('refill_buffers\n')
                        writer.write('buffer_compress_percentage=%s\n' % profile[Constant.C_OPTION])

                    if percent_sequential == Constant.ONE_HUNDRED:      # fully sequential workload
                        writer.write('percentage_random=0\n')
                        writer.write('rwmixread=%s\n' % str(percent_mix))
                        writer.write('rwmixwrite=%s\n' % str(Constant.ONE_HUNDRED - percent_mix))
                        if percent_mix == Constant.ONE_HUNDRED:         # sequential read
                            writer.write('rw=read\n')
                        elif percent_mix == Constant.ZERO:              # sequential write
                            writer.write('rw=write\n')
                        else:                                           # sequential mixed reads and writes
                            writer.write('rw=rw\n')
                    elif percent_sequential == Constant.ZERO:           # fully random workload
                        writer.write('percentage_random=100\n')
                        writer.write('rwmixread=%s\n' % str(percent_mix))
                        writer.write('rwmixwrite=%s\n' % str(Constant.ONE_HUNDRED - percent_mix))
                        if percent_mix == Constant.ONE_HUNDRED:         # random read
                            writer.write('rw=randread\n')
                        elif percent_mix == Constant.ZERO:              # random write
                            writer.write('rw=randwrite\n')
                        else:
                            writer.write('rw=randrw\n')               # random mixed reads and writes
                    else:                                               # workload between 0 to 100
                        writer.write('percentage_random=%s\n' % str(Constant.ONE_HUNDRED - percent_sequential))
                        writer.write('rwmixread=%s\n' % str(percent_mix))
                        writer.write('rwmixwrite=%s\n' % str(Constant.ONE_HUNDRED - percent_mix))
                        writer.write('rw=randrw\n')

            # we update the list and dictionary needed for executing fio program
            fio_list = (access_type, job_dir_n_file, job_log_dir_n_file, blocksize)
            fio_dict[int(testnum)] = fio_list
    return fio_dict


def util_create_summary_fio_log(fio_dict, serial_number, temperature, workload):
    # get the current working directory
    curr_dir = os.getcwd()

    # current log directory
    job_log_folder = curr_dir + os.sep + Constant.LOG_FOLDER_NAME

    # separate the filename and file extension into two separate variables
    filename, extension = os.path.splitext(workload)

    # get the time and date then append to job config file and log file
    now = time.strftime("%m%d%Y") + Constant.UNDERSCORE + \
          time.strftime("%H%M")

    # set the initial job log filename
    job_log_filename = Constant.JOB_LOG_FILENAME + Constant.UNDERSCORE + filename + \
                       Constant.UNDERSCORE + serial_number + \
                       Constant.UNDERSCORE + temperature + \
                       Constant.UNDERSCORE + now

    # we set the job summary log filename based on the test number
    job_log_filename = job_log_filename + Constant.UNDERSCORE + \
                       Constant.ALL_JOB_LOG_FILENAME + Constant.LOG_FILE_EXTENSION
    job_log_dir_n_file = job_log_folder + os.sep + job_log_filename

    # now we merge all logs from all jobs
    with open(job_log_dir_n_file, 'wb') as outfile:
        # we now scan the fio dict for the individual job logs
        for entry_num, entry_list in fio_dict.items():
            # index two of the entry list is the individual job log file
            job_log = entry_list[Constant.TWO]
            with open(job_log, 'rb') as infile:
                outfile.write(infile.read())
            # we add a new line before updating for the next job log file
            # outfile.write('\n')
    return
